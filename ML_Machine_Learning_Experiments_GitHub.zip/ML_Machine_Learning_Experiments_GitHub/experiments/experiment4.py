
import numpy as np

# Input dataset (XOR)
X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

Y = np.array([[0], [1], [1], [0]])

# Initialize weights
np.random.seed(1)
W1 = np.random.randn(2, 4)
W2 = np.random.randn(4, 1)

b1 = np.zeros((1, 4))
b2 = np.zeros((1, 1))

# Sigmoid function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Training
learning_rate = 0.5

for epoch in range(10000):

    # Forward propagation
    hidden = sigmoid(np.dot(X, W1) + b1)
    output = sigmoid(np.dot(hidden, W2) + b2)

    # Backpropagation
    error = Y - output
    d_output = error * output * (1 - output)

    d_hidden = np.dot(d_output, W2.T) * hidden * (1 - hidden)

    W2 += learning_rate * np.dot(hidden.T, d_output)
    W1 += learning_rate * np.dot(X.T, d_hidden)

    b2 += learning_rate * np.sum(d_output, axis=0)
    b1 += learning_rate * np.sum(d_hidden, axis=0)

# Display results
print("Input:")
print(X)

print("\nPredicted Output:")
print(np.round(output))

print("\nActual Output:")
print(Y)