
from sklearn.linear_model import LinearRegression

# Training dataset
# Month number and sales
X = [[1], [2], [3], [4], [5], [6]]
y = [100, 120, 140, 160, 180, 200]

# Create model
model = LinearRegression()

# Train model
model.fit(X, y)

# Predict future sales
future_month = [[7]]
prediction = model.predict(future_month)

# Display result
print("Future Sales Prediction")
print("Month:", future_month[0][0])
print("Predicted Sales:", prediction[0])