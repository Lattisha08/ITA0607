
from sklearn.linear_model import LinearRegression

# Training dataset
# Car age and price (in lakhs)
X = [[1], [2], [3], [4], [5], [6]]
y = [18, 16, 14, 12, 10, 8]

# Create model
model = LinearRegression()

# Train model
model.fit(X, y)

# Predict car price
age = [[3]]
prediction = model.predict(age)

# Display result
print("Car Price Prediction")
print("Car Age:", age[0][0], "years")
print("Predicted Price:", prediction[0], "Lakhs")