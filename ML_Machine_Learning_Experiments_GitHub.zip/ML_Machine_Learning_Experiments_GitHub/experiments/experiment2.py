
import csv

with open("training_data.csv", "r") as file:
    data = list(csv.reader(file))

header = data[0]
examples = data[1:]

S = ['0'] * 6
G = [['?'] * 6]

for example in examples:
    attributes = example[:-1]
    target = example[-1]

    if target == "Yes":
        for i in range(6):
            if S[i] == '0':
                S[i] = attributes[i]
            elif S[i] != attributes[i]:
                S[i] = '?'

        G = [g for g in G if all(
            g[i] == '?' or g[i] == attributes[i]
            for i in range(6)
        )]

    else:
        new_G = []

        for g in G:
            if all(g[i] == '?' or g[i] == attributes[i]
                   for i in range(6)):
                for i in range(6):
                    if S[i] != '?' and S[i] != '0':
                        if attributes[i] != S[i] and g[i] == '?':
                            h = g.copy()
                            h[i] = S[i]
                            new_G.append(h)
            else:
                new_G.append(g)

        G = new_G

print("Specific Boundary (S):")
print(S)

print("\nGeneral Boundary (G):")
for g in G:
    print(g)
