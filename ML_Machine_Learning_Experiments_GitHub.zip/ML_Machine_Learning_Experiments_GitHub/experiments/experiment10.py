
import numpy as np
from sklearn.mixture import GaussianMixture

# Dataset
X = np.array([
    [1.0], [1.5], [2.0], [2.5],
    [8.0], [8.5], [9.0], [9.5]
])

# Create EM model
model = GaussianMixture(
    n_components=2,
    random_state=42
)

# Train model
model.fit(X)

# Predict clusters
labels = model.predict(X)

# Display results
print("Expectation Maximization Algorithm")
print("Cluster Labels:")
print(labels)

print("\nCluster Means:")
print(model.means_)