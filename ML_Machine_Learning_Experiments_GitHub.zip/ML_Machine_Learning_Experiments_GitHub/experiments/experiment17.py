
from sklearn.tree import DecisionTreeClassifier

# Training dataset
# RAM, Battery, Camera
X = [
    [2, 3000, 8],
    [3, 3500, 12],
    [4, 4000, 16],
    [6, 4500, 24],
    [8, 5000, 32],
    [12, 6000, 48],
    [4, 3000, 12],
    [6, 4000, 16]
]

# Price categories
y = [
    'Low', 'Low', 'Medium', 'Medium',
    'High', 'High', 'Low', 'Medium'
]

# Create model
model = DecisionTreeClassifier(random_state=0)

# Train model
model.fit(X, y)

# Predict mobile price category
sample = [[8, 5000, 32]]
prediction = model.predict(sample)

# Display result
print("Mobile Price Prediction")
print("RAM:", sample[0][0], "GB")
print("Battery:", sample[0][1], "mAh")
print("Camera:", sample[0][2], "MP")
print("Predicted Price Category:", prediction[0])