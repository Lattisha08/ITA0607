
from sklearn.tree import DecisionTreeClassifier

# Training dataset
X = [
    [750, 30000, 10],
    [680, 25000, 20],
    [550, 15000, 50],
    [500, 12000, 60],
    [800, 50000, 5],
    [580, 18000, 45]
]

y = ['Good', 'Good', 'Poor', 'Poor', 'Good', 'Poor']

# Create model
model = DecisionTreeClassifier(random_state=0)

# Train model
model.fit(X, y)

# Predict credit score
sample = [[720, 35000, 10]]
prediction = model.predict(sample)

# Display result
print("Credit Score Classification")
print("Credit Score:", sample[0][0])
print("Annual Income:", sample[0][1])
print("Debt Percentage:", sample[0][2])
print("Credit Category:", prediction[0])