
from sklearn.linear_model import LinearRegression

# Training data
X = [[1], [2], [3], [4], [5]]
y = [2, 4, 6, 8, 10]

# Create model
model = LinearRegression()

# Train model
model.fit(X, y)

# Predict output
prediction = model.predict([[6]])

# Display results
print("Linear Regression")
print("Slope:", model.coef_[0])
print("Intercept:", model.intercept_)
print("Predicted Value:", prediction[0])