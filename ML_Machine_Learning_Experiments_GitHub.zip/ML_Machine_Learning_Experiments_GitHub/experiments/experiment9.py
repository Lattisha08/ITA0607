
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

# Dataset
X = np.array([[1], [2], [3], [4], [5]])
y = np.array([1, 4, 9, 16, 25])

# Linear Regression
linear = LinearRegression()
linear.fit(X, y)

linear_pred = linear.predict([[6]])

# Polynomial Regression
poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X)

model = LinearRegression()
model.fit(X_poly, y)

new_data = poly.transform([[6]])
poly_pred = model.predict(new_data)

# Display results
print("Linear Regression Prediction:", linear_pred[0])
print("Polynomial Regression Prediction:", poly_pred[0])