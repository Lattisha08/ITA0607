
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder

# Dataset
data = {
    'Outlook': ['Sunny', 'Sunny', 'Overcast', 'Rainy',
                'Rainy', 'Rainy', 'Overcast', 'Sunny'],
    'Temperature': ['Hot', 'Hot', 'Hot', 'Mild',
                    'Cool', 'Cool', 'Cool', 'Mild'],
    'Humidity': ['High', 'High', 'High', 'High',
                 'Normal', 'Normal', 'Normal', 'High'],
    'Play': ['No', 'No', 'Yes', 'Yes',
             'Yes', 'No', 'Yes', 'No']
}

df = pd.DataFrame(data)

# Encode categorical values
encoders = {}
for column in df.columns:
    le = LabelEncoder()
    df[column] = le.fit_transform(df[column])
    encoders[column] = le

# Build ID3 Decision Tree
X = df.drop('Play', axis=1)
y = df['Play']

model = DecisionTreeClassifier(criterion='entropy', random_state=0)
model.fit(X, y)

# Predict new sample
sample = pd.DataFrame([{
    'Outlook': encoders['Outlook'].transform(['Overcast'])[0],
    'Temperature': encoders['Temperature'].transform(['Hot'])[0],
    'Humidity': encoders['Humidity'].transform(['Normal'])[0]
}])

prediction = model.predict(sample)

print("Decision Tree Classification")
print("New Sample: Overcast, Hot, Normal")
print("Prediction:", encoders['Play'].inverse_transform(prediction)[0])