
from sklearn.linear_model import LinearRegression

# Training dataset
# House size in square feet
X = [[500], [800], [1000], [1200], [1500], [1800]]

# House price in lakhs
y = [15, 24, 30, 36, 45, 54]

# Create model
model = LinearRegression()

# Train model
model.fit(X, y)

# Predict house price
size = [[1400]]
prediction = model.predict(size)

# Display result
print("House Price Prediction")
print("House Size:", size[0][0], "sq.ft")
print("Predicted Price:", prediction[0], "Lakhs")