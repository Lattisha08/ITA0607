# Machine Learning Experiments

This repository contains 20 Python machine-learning experiments and a PDF containing screenshots of the code execution and outputs.

## Repository structure

```text
ML_Machine_Learning_Experiments/
├── data/
│   └── training_data.csv
├── experiments/
│   ├── experiment1.py
│   ├── experiment2.py
│   ├── ...
│   └── experiment20.py
├── outputs/
│   └── ML_outputs.pdf
├── requirements.txt
└── README.md
```

## Requirements

- Python 3.9 or later
- NumPy
- pandas
- scikit-learn

## Setup

Clone the repository and open the project folder:

```bash
git clone <your-repository-url>
cd ML_Machine_Learning_Experiments
```

Create and activate a virtual environment (recommended):

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS / Linux:

```bash
source .venv/bin/activate
```

Install the required packages:

```bash
pip install -r requirements.txt
```

## Run an experiment

Run any experiment from the project root. For example:

```bash
python experiments/experiment1.py
```

For the experiment that reads the training dataset, keep `data/training_data.csv` in the project and run the script from the repository root. If a script uses a relative filename, run it from the project root so it can find the data file.

## Output reference

The `outputs/ML_outputs.pdf` file contains the supplied screenshots showing experiment code and terminal outputs. It is included as a reference document; it is not required to run the Python scripts.

## Notes

- Each experiment is kept as a separate Python file.
- The original experiment scripts and CSV data are included.
- Some experiments use built-in datasets from scikit-learn, while the CSV-based experiment uses the supplied training data.
